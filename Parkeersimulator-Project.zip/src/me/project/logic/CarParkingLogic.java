package me.project.logic;

import java.util.Random;

import me.project.abstracts.AbstractModel;
import me.project.abstracts.Car;
import me.project.model.AdHocCar;
import me.project.model.CarQueue;
import me.project.model.ElectricalCar;
import me.project.model.Location;
import me.project.model.ParkingPassCar;
import me.project.model.ReservationCar;

	/**
	 * This class contains all the logic for the simulator
	 * @author Bryan Dijkhuizen, Thalisa Jagt
	 * @version 2.2.0 (22-01-2019)
	 */

public class CarParkingLogic extends AbstractModel {
    private static int numberOfFloors, numberOfRows, numberOfPlaces;
    @SuppressWarnings("unused")
	private static CarQueue entranceCarQueue,  paymentCarQueue, MembersExitQueue, exitCarQueue, MembersSecondExitQueue, secondEntranceCarQueue, MemberQueue ;

    private Car[][][] cars;
    
    private int amountOfMembers;
    private int amountOfReservations;
    private int amountOfElectricals;
    private int amountOfRegularCars;
    
    private int month = 0;
    private int week = 0;
    private int day = 0;
    private int hour = 0;
    private int minute = 0;

    private int weekDayArrivals;
    private int weekendArrivals;

    private int enterSpeed;
    private int paymentSpeed;
    private int exitSpeed; 
    
    private int maxCarsInQueue;
    
    private int numberOfEnteringCars; 
    private int numberOfPayingCars; 
    private int numberOfExitingCars; 
    private int numberOfMembersExiting;
    private int numberOfReservationsExiting;

    private int totalRegularCarsInPark, totalMembersInPark, totalCars, totalReservationsInPark, totalElectricalsInPark; 
    private int totalSpace;
    
    private String currentDay;
    private String currentTime;
    
    private double pricePerMinute = 0.116;
    private double MembersRevenue = 0;
    private double totalRevenue = 0 + MembersRevenue;
    private double totalMissedRevenue = 0;


    /**
     * CarParkingLogic Constructor 
     * @param numberOfFloors 
     * @param numberOfRows   
     * @param numberOfPlaces 
     */
    
    @SuppressWarnings("static-access")
	public CarParkingLogic(int numberOfFloors, int numberOfRows, int numberOfPlaces) {
        this.numberOfFloors = numberOfFloors;
        this.numberOfRows = numberOfRows;
        this.numberOfPlaces = numberOfPlaces;
        
        cars = new Car[numberOfFloors][numberOfRows][numberOfPlaces];
        
        entranceCarQueue = new CarQueue();
        secondEntranceCarQueue = new CarQueue();
        paymentCarQueue = new CarQueue();
        MembersExitQueue = new CarQueue();
        exitCarQueue = new CarQueue();
        MemberQueue = new CarQueue();
        //MembersSecondExitQueue = new CarQueue();
        
        maxCarsInQueue = 30;
        enterSpeed = 3; //number of cars that can enter per minute
        paymentSpeed = 10; 
        exitSpeed = 9; 
        totalSpace = numberOfPlaces * numberOfRows * numberOfFloors; //max amount of places in parking lot 
        
        numberOfEnteringCars = 0;
        numberOfPayingCars = 0;
        numberOfExitingCars = 0;
        numberOfMembersExiting = 0;

        totalRegularCarsInPark = 0;
        totalMembersInPark = 0;
        totalElectricalsInPark = 0;
        totalCars = 0;
        
        amountOfRegularCars = 360;
        amountOfMembers = 90;
        amountOfReservations = 60;
        amountOfElectricals = 30;

        currentDay = "Monday";
        
        currentTime = hour + ":" + minute;
    }
    
    /**
     * Run the simulator
     */
    
    public void run() {
        for (int i = 0; i < 10000; i++) {
            tick();
        }
    }
    
    /**
     * @return numberOfFloors 
     */
    
    public int getNumberOfFloors() {
        return numberOfFloors;
    }
 
    /**
     * @return numberOfRows
     */
    
    public int getNumberOfRows() {
        return numberOfRows;
    }

    /**
     * @return numberOfPlaces 
     */
    
    public int getNumberOfPlaces() {
        return numberOfPlaces;
    }

    /**
     * @return cars 
     */
    
    public Car[][][] getCars() {
        return cars;
    }

    /**
     * @return cars 
     */
    
    public CarQueue getEntranceCarQueue() {
        return entranceCarQueue;
    }
    
    /**
     * @return cars of second queue
     */
    
    public CarQueue getSecondEntranceCarQueue() {
    	return secondEntranceCarQueue;
    }
    
    /**
     * @return cars in the payment car queue
     */
     
    public CarQueue getPaymentCarQueue() {
        return paymentCarQueue;
    }

    /**
     * @return cars in the exiting car queue
     */
    
    public CarQueue getExitCarQueue() {
        return exitCarQueue;
    }
    
    /**
     * @return enterSpeed
     */
    
	public int getEnterSpeed() {
		return enterSpeed;
	}
	
    /**
     * @return paymentSpeed
     */
	
	public int getPaySpeed() {
		return paymentSpeed;
	}
	
    /**
     * @return exitSpeed 
     */
	
	public int getExitSpeed(){
		return exitSpeed;
	}
	
	/**
     * @return numberOfEnteringCars
     */
    
    public int getNumberOfEntering() {
        return numberOfEnteringCars;
    }

    /**
     * @return numberOfPayingCars
     */
    
    public int getNumberOfPaying() {
        return numberOfPayingCars;
    }

    /**
     * @return numberOfExitingCars
     */
    
    public int getNumberOfExiting() {
        return numberOfExitingCars;
    }
    
    /**
     * @return numberOfExitingCars
     */
    
    public int getNumberOfExitingMemberss() {
        return numberOfMembersExiting;
    }
    
    /**
     * @return totalCars 
     */
    
    public int getTotalRegularCars() {
        return totalRegularCarsInPark;
    }

   
    /**
     * @return totalCars 
     */
    
    public int getTotalMembers() {
        return totalMembersInPark;
    }
    
    /**
     * @return amountOfMembers
     */
    
    public int getNumberOfMembers(){
    	return amountOfMembers;
    }
    
    /**
     * @return carsInQueue
     */
    
    
    public int getCarsInEntranceQueue() {
    	return entranceCarQueue.carsInQueue();
    }
    /**
     * @return carsInSecondQueue
     */
    

    public int getCarsInSecondEntranceQueue() {
    	return secondEntranceCarQueue.carsInQueue();
    }

    /**
     * Gets the current day
     * @return currentDay
     */
    
    public String getCurrentDay() {
    	return currentDay;
    }
    
    /**
     * @return MemberQueue
     */
    
    public CarQueue getMembersQueue() {
    	return MemberQueue;
    }
    
    /**
     * @return currentTime
     */
    
    public String getCurrentTime() {
    	return currentTime;
    }
	
	/**
     * Simulates one step, it advances the time by one minute.
     */
	
    public int getAmountOfReservations() {
		return amountOfReservations;
	}
    

	
	/**
	 * @return numberOfReservationsExiting
	 */
	
	public int getNumberOfReservationsExiting() {
		return numberOfReservationsExiting;
	}

	/**
	 * 
	 * @param numberOfReservationsExiting
	 */

	public void setNumberOfReservationsExiting(int numberOfReservationsExiting) {
		this.numberOfReservationsExiting = numberOfReservationsExiting;
	}
	
	/**
	 * @return totalReservationsInPark
	 */
	
	public int getTotalReservations() {
		return totalReservationsInPark;
	}
	
	/** 
	 * @return totalCars
	 */
	
	public int getTotalCars() {
		return totalCars;
	}
	
	/**
	 * @return totalRevenu
	 */
	
	public int getTotalRevenue() {
		return (int) Math.round(totalRevenue);
	}
	
	/**
	 * @return totalElectricalsInPark
	 */
	
	public int getTotalElectricals() {
		return totalElectricalsInPark;
	}
	
	/**
	 * @param speed
	 */
	
	public void setEnterSpeed(int enterSpeed) {
		this.enterSpeed = enterSpeed;
	}
	
	/**
	 * @param speed
	 */
	
	public void setExitSpeed(int exitSpeed) {
		this.exitSpeed = exitSpeed;
	}
	
	/**
	 * @return totalMissedRevenue
	 */
	
	public int getTotalMissedRevenue() {
		return (int)Math.round(totalMissedRevenue);
	}

	/**
	 * @return maxCarsInQueue
	 */
	
	public int getMaxCarsInQueue() {
		return maxCarsInQueue;
	}
	
	/**
	 * @param int maxCars
	 */
	
	public void setMaxCarsInQueue(int maxCars) {
		maxCarsInQueue = maxCars;
	}
	
	/**
	 * @return ticketPrice per hour
	 */
	
	public double getTicketPrice() {
		return (pricePerMinute * 60);
	}
	
	/**
	 * @param pricePerHour
	 */
	
	public void setTicketPrice(double pricePerHour) {
		pricePerMinute = pricePerHour / 60;
	}
	
	/**
	 * @return hour
	 */
	
	public int getCurrentHour() {
		return hour;
	}
	
	/**
	 * @return minute
	 */
	
	public int getCurrentMinute() {
		return minute;
	}
	
	
	/**
	 * Tick method actually simulates the
	 * carpark
	 */
	
	public void setIsOpen(CarQueue carQueue, boolean isOpen) {
		carQueue.setIsOpen(isOpen);
	}
	
    public void tick() {
    		
    	/*
    	 * All the regular amount of cars in the 
    	 * carpark
    	 */
    	
    	if(day >=0 && day <= 2) {
	    	if(hour > 0 && hour < 7) {
	        	weekDayArrivals = 20;
	        	weekendArrivals = 21;
	        } else if(hour > 5 && hour < 7) {
	    		weekDayArrivals = 20;
	        	weekendArrivals = 30;
	    	} else if (hour >= 7 && hour < 9) {
	    		weekDayArrivals = 75;
	        	weekendArrivals = 100;
	    	} else if (hour >= 9 && hour < 17) {
	    		weekDayArrivals = 40;
	        	weekendArrivals = 80;
	    	} else if (hour >= 17 && hour < 21) {
	    		weekDayArrivals = 30;
	        	weekendArrivals = 40;
	    	} else if (hour >= 21 && hour < 23) {
	    		weekDayArrivals = 20;
	        	weekendArrivals = 21;
	    	}
    }
    	
    	/*
    	 * Thursday night will be busy
    	 */
    	
    	if(day == 3) {
    		if(hour > 0 && hour < 7) {
            	weekDayArrivals = 20;
            	weekendArrivals = 21;
            } else if(hour > 5 && hour < 7) {
        		weekDayArrivals = 20;
            	weekendArrivals = 30;
        	} else if (hour >= 7 && hour < 9) {
        		weekDayArrivals = 75;
            	weekendArrivals = 100;
        	} else if (hour >= 9 && hour < 17) {
        		weekDayArrivals = 40;
            	weekendArrivals = 80;
        	} else if (hour >= 17 && hour < 21) {
        		weekDayArrivals = 100;
            	weekendArrivals = 200;
        	} else if (hour >= 21 && hour < 23) {
        		weekDayArrivals = 20;
            	weekendArrivals = 21;
        	}
    	}
    	
    	/*
    	 * Friday & Saturday will be busy
    	 */
    	
    	if(day >= 4 && day <= 5) {
    		if(hour > 0 && hour < 7) {
            	weekDayArrivals = 20;
            	weekendArrivals = 21;
            } else if(hour > 5 && hour < 7) {
        		weekDayArrivals = 20;
            	weekendArrivals = 30;
        	} else if (hour >= 7 && hour < 9) {
        		weekDayArrivals = 75;
            	weekendArrivals = 100;
        	} else if (hour >= 9 && hour < 13) {
        		weekDayArrivals = 60;
            	weekendArrivals = 100;
        	}else if (hour >= 13 && hour < 17)	{
        		weekDayArrivals = 60;
            	weekendArrivals = 140;
        	} else if (hour >= 17 && hour < 21) {
        		weekDayArrivals = 150;
            	weekendArrivals = 250;
        	} else if (hour >= 21 && hour < 23) {
        		weekDayArrivals = 40;
            	weekendArrivals = 60;
        	}
    	}
    	
    	/*
    	 * Sunday in the afternoon will be busy
    	 */
    	
    	if(day == 6) {
    		if(hour > 0 && hour < 7) {
            	weekDayArrivals = 20;
            	weekendArrivals = 21;
            } else if(hour > 5 && hour < 7) {
        		weekDayArrivals = 20;
            	weekendArrivals = 30;
        	} else if (hour >= 7 && hour < 9) {
        		weekDayArrivals = 20;
            	weekendArrivals = 30;
        	} else if (hour >= 9 && hour < 17) {
        		weekDayArrivals = 60;
            	weekendArrivals = 140;
        	} else if (hour >= 17 && hour < 21) {
        		weekDayArrivals = 20;
            	weekendArrivals = 30;
        	} else if (hour >= 21 && hour < 23) {
        		weekDayArrivals = 20;
            	weekendArrivals = 21;
        	}
    	}

    	/*
    	 * The time will be advanced here
    	 */
    	
    	minute++;
        while (minute > 59) {
            minute -= 60;
            hour++;
        }
        while (hour > 23) {
            hour -= 24;
            day++;  
        }
        while (day > 6) {
            day -= 7;
            week++;
            totalRevenue = 0;
            totalMissedRevenue = 0;
        }    
        while (week > 3) {
        	week -= 4;
        	month++;
        	MembersRevenue += 100 * amountOfMembers;
        }
        while (month > 11) {
        	month -= 12;
        	
        }
        
        /* 
         * these if statements will make sure the time will
         * be displayed
         */
        
        if(hour < 10) {
        	currentTime = "0"+ hour + ":" + minute;
        }
        
        if (minute < 10) {
        	currentTime = hour + ":" + "0" + minute;
        }else {
        	currentTime = hour + ":" + minute;
        }
        	
        /*
         * The Switch case that creates the days
         */
        
        switch (day) {
        case 0: 
        	currentDay = "Monday";
        	break;
        case 1:
        	currentDay = "Tuesday";
        	break;
        case 2:
        	currentDay = "Wednesday";
        	break;
        case 3:
        	currentDay = "Thursday";
        	break;
        case 4: 
        	currentDay = "Friday";
        	break;
        case 5:
        	currentDay = "Saturday";
        	break;
        case 6:
        	currentDay = "Sunday";
        	break;
        }
        
        /*
         * A random object gets defined here.
         */

        Random random = new Random();
        
        /*
         * The average numbers are calculated here.
         */

        int averageNumberOfCarsPerHour = day < 5 ? weekDayArrivals : weekendArrivals;
                
        double standardDeviation = averageNumberOfCarsPerHour * 0.3;
        double numberOfRegularCarsPerHour = averageNumberOfCarsPerHour + random.nextGaussian() * standardDeviation;
        int numberOfRegularCarsPerMinute = (int)Math.round(numberOfRegularCarsPerHour / 60);
        
        double numberOfReservationsPerHour = (amountOfReservations / 5)  + random.nextGaussian() * standardDeviation;
        int numberOfReservationsPerMinute = (int)Math.round(numberOfReservationsPerHour / 60);
        
        double numberOfElectricalsPerHour = amountOfElectricals + random.nextGaussian() * standardDeviation;
        int numberOfElectricalsPerMinute = (int)Math.round(numberOfElectricalsPerHour / 60);
 
        double numberOfParkingMembersPerHour = (amountOfMembers / 20) + random.nextGaussian() * standardDeviation;
        int numberOfParkingMembersPerMinute = (int)Math.round(numberOfParkingMembersPerHour / 60);
        int numberTotalCarsPerMinute = numberOfRegularCarsPerMinute + numberOfParkingMembersPerMinute + numberOfReservationsPerMinute + numberOfElectricalsPerMinute;
              
        /**
         * Here will the Car Park be simulated.
         */
  
        /*
		 * The cars will enter until 
	 	 * the maximum amount of cars per minute was reached
	 	 */
        
        for (int j = 0; j < numberTotalCarsPerMinute; j++) { 	
        	
        	/*
        	 * This will remove the cars from the entrance queues
        	 * if the queue gets too long
        	 */
        	
        	for(int i = 0; i < entranceCarQueue.carsInQueue(); i++) {
        		if(entranceCarQueue.carsInQueue() > maxCarsInQueue) {
        			@SuppressWarnings("unused")
					Car car = entranceCarQueue.removeCar();
        			totalMissedRevenue += 7.5 / 2;
        		}
        	}
        	
        	for(int i = 0; i < secondEntranceCarQueue.carsInQueue(); i++) {
        		if(secondEntranceCarQueue.carsInQueue() > maxCarsInQueue) {
        			@SuppressWarnings("unused")
        			Car car = secondEntranceCarQueue.removeCar();
        			totalMissedRevenue += 7.5;
        		}
        	}
        	
        		/*
				 * As long as the maximum of regular cars entering the 
				 * parking hasn't been reached regular cars will enter
				 */
        	
            for (int i = 0; i < numberOfRegularCarsPerMinute; i++) {	
                Car car = new AdHocCar();
                	if(entranceCarQueue.isOpen() == true) {
                		numberOfEnteringCars++;
                		entranceCarQueue.addCar(car);
                	} else {
                		numberOfEnteringCars++;
                		secondEntranceCarQueue.addCar(car);
                	}
            }
                
            
            	/*
            	 * As long as the maximum of ParkingMembers cars entering the 
            	 * parking hasn't been reached ParkingMembers cars will enter
            	 */
            

            for (int i = 0; i < numberOfParkingMembersPerMinute; i++) {
            	Car car = new ParkingPassCar();
            		if(secondEntranceCarQueue.isOpen() == true) {
            			numberOfEnteringCars++;
    	                secondEntranceCarQueue.addCar(car);
            		} else {
            			numberOfEnteringCars++;
            			entranceCarQueue.addCar(car);
            		}
	            	
          
            }
            
            /*
             * As long as the maximum of Reservations cars entering the parking hasn't
             * been reached, they will enter
             * 
             */
            
            for (int i = 0; i < numberOfReservationsPerMinute; i++) {
            	Car car = new ReservationCar();
            		if(secondEntranceCarQueue.isOpen()) {
            			numberOfEnteringCars++;
                    	secondEntranceCarQueue.addCar(car);
            		} else {
            			numberOfEnteringCars++;
            			entranceCarQueue.addCar(car);
            		}
            	
            
            }
            	
            	/*
            	 * As long as the maximum of Electrical cars entering the parking hasn't
            	 * been reached, they will enter
            	 */
            	
            for(int i = 0; i < numberOfElectricalsPerMinute; i++) {
        			Car car = new ElectricalCar();
        				if(entranceCarQueue.isOpen()) {
        					numberOfEnteringCars++;
                			entranceCarQueue.addCar(car);
        				} else {
        					numberOfEnteringCars++;
        					secondEntranceCarQueue.addCar(car);
        				}
        			
        			
            }

            super.notifyViews(); //updates the CarParkView
        }
        
        /*
         * For as long as the maximum enterSpeed hasn't been reached
         * The Car will be removed from the EntranceQueue and the NumberOfEnteringCars will be decreased 
         * by 1. This will be done with every car-type to make sure the car will be put into the right spot 
         * this will be done with the getFirstFreeLocationFor..() methods.
         */

        for(int i = 0; i < enterSpeed; i++){
        	if(totalCars < totalSpace){ //checks if park is full
        		if(totalRegularCarsInPark < amountOfRegularCars) { //checks if the amount of cars in the park is not full
        		Car car = entranceCarQueue.removeCar(); //removes the car from the queue
        		numberOfEnteringCars--; //number of entering cars will be decreased
        		
        		if(car == null){
        			break;
        		} else {
        			if(car instanceof AdHocCar && getFirstFreeLocationForRegular() != null){
        				this.setCarAt(getFirstFreeLocationForRegular(), car); //checks which type car the spot has to be for
        			} else {
        				break;
        			}
        			
        			if(car instanceof AdHocCar){
        				totalRegularCarsInPark++; //total car amount in park will be increased by 1
        			}
        			
        			if(car instanceof AdHocCar){
        				car.setMinutesLeft(car.getStayTime());	 
        			}
        		}
        		super.notifyViews();
        	}
        	this.tickCars();
        }
     }
        
        for(int i = 0; i < enterSpeed; i++){
        	if(totalCars < totalSpace){
        		if(totalElectricalsInPark < amountOfElectricals) {
        		Car car = entranceCarQueue.removeCar();
        		numberOfEnteringCars--;
        		
        		if(car == null){
        			break;
        		} else {
        			if(car instanceof ElectricalCar && getFirstFreeLocationForElec() != null){
        				this.setCarAt(getFirstFreeLocationForElec(), car);
        			} else {
        				break;
        			}
        			
        			if(car instanceof ElectricalCar){
        				totalElectricalsInPark++;
        			}
        			
        			if(car instanceof ElectricalCar){
        				car.setMinutesLeft(car.getStayTime());	
        			}
        		}
        		super.notifyViews();
        	}
        	this.tickCars();
        }
    }
        
        for(int i = 0; i < enterSpeed; i++){
        	if(totalCars < totalSpace){
        		if(totalMembersInPark < amountOfMembers) {
        		Car car = secondEntranceCarQueue.removeCar();
        		numberOfEnteringCars--;
        		
        		if(car == null){
        			break;
        		} else {
        			if(car instanceof ParkingPassCar && getFirstFreeLocationForPass() != null){
        				this.setCarAt(getFirstFreeLocationForPass(), car);
        			} else {
        				break;
        			}
        			
        			if(car instanceof ParkingPassCar){
        				totalMembersInPark++;
        			}
        			
        			if(car instanceof ParkingPassCar){
        				car.setMinutesLeft(car.getStayTime());	
        			}
        		}
        		super.notifyViews();
        	}
        	this.tickCars();
        }
     }
        
        for(int i = 0; i < enterSpeed; i++){
        	if(totalCars < totalSpace){
        		if(totalReservationsInPark < amountOfReservations) {
        		Car car = secondEntranceCarQueue.removeCar();
        		numberOfEnteringCars--;
        		
        		if(car == null){
        			break;
        		} else {
        			if(car instanceof ReservationCar && getFirstFreeLocationForRes() != null){
        				this.setCarAt(getFirstFreeLocationForRes(), car);
        			} else {
        				break;
        			}
        			
        			if(car instanceof ReservationCar){
        				totalReservationsInPark++;
        			}
        			
        			if(car instanceof ReservationCar){
        				car.setMinutesLeft(car.getStayTime());	
        			}
        		}
        		super.notifyViews();
        	}
        	this.tickCars();
        }
      }
      
        /*
         * This while loop will get the first leaving car and puts it into the paymentCarQueue except for the Memberss 
         */
                
        while(true) {
        	Car car = this.getFirstLeavingCar();
        	
        	if(car == null) {
        		break;
        	}
        
            if(car instanceof AdHocCar && car.getMinutesLeft() <= 0){
            	numberOfPayingCars++;
            	paymentCarQueue.addCar(car); // Car gets added to the payment Queue 
            	totalRevenue += car.getStayTime() * pricePerMinute;
            	break;
            	
            } else if (car instanceof ElectricalCar && car.getMinutesLeft() <= 0) {
            	numberOfPayingCars++;
            	paymentCarQueue.addCar(car);
            	totalRevenue += car.getStayTime() * pricePerMinute;
            	break;
	
            } else if(car instanceof ParkingPassCar && car.getMinutesLeft() <= 0) { 
            	numberOfMembersExiting++;
	            	MembersExitQueue.addCar(car); // Car gets added to the MemberssCarQueue to leave
	                this.removeCarAt(car.getLocation()); //Car gets removed from it's location
	                break;
            	    	
            } else if(car instanceof ReservationCar && car.getMinutesLeft() <= 0) {
            	numberOfPayingCars++;
            	setNumberOfReservationsExiting(getNumberOfReservationsExiting() + 1);
            	paymentCarQueue.addCar(car);
            	totalRevenue += car.getStayTime() * pricePerMinute;
            	break;
            
            }
            
            super.notifyViews();
        }

        /*
         * Here will the payments be done.
         * This will happen until the maximum amount of 'payers' has been reached
         */

        for (int i = 0; i < paymentSpeed; i++) {
            Car car = paymentCarQueue.removeCar();  //car will be removed from the payment Queue
            if (car == null) { //car has to exist else there will be a break
                break;
            } else if(car instanceof AdHocCar){
                numberOfPayingCars--;
                exitCarQueue.addCar(car); //car will be added to the exiting car queue
                numberOfExitingCars++;
        
            } else if (car instanceof ReservationCar) {
            	numberOfPayingCars--;
            	exitCarQueue.addCar(car);
            	setNumberOfReservationsExiting(getNumberOfReservationsExiting() + 1);
            } else if (car instanceof ElectricalCar) {
            	numberOfPayingCars--;
            	exitCarQueue.addCar(car); //car will be added to the exiting car queue
            	numberOfExitingCars++;
            }

            this.removeCarAt(car.getLocation()); //car gets removed from it's location

            super.notifyViews(); //view gets updated
        }
        
        /**
         * Here the Memberss/parkingMembers will be entering in their entrance
         * until the maximum amount of cars has been reached
         */
        
        for (int i = 0; i < enterSpeed; i++) {
        	
        }
        /*
         * Here the regular & electrical cars will be leaving
         * until the maximum amount of cars has been reached
         */
        
        for (int i = 0; i < exitSpeed; i++) {
            Car car = exitCarQueue.removeCar(); //car gets removed from exiting car queue
            if (car == null) { //car has to exist else there will be a break
                break;
            } else if(car instanceof AdHocCar){
                numberOfExitingCars--;	 //exiting car queue will me decreased by 1
                totalRegularCarsInPark--;	     //total regular car count will be decreased by 1
            } else if(car instanceof ElectricalCar) {
            	numberOfExitingCars--;
            	totalElectricalsInPark--;
            } else if (car instanceof ReservationCar) {
            	numberOfExitingCars--;
            	totalReservationsInPark--;
            }
            
            super.notifyViews();
 
        }
        
        /*
         * Here the Memberss/ParkingMember will be leaving
         * Until the maximum amount of cars has been reached
         */
        
        for (int i = 0; i < exitSpeed; i++) {
            Car car = MembersExitQueue.removeCar(); //car gets removed from the Memberss exiting queue
            if (car == null) { //car has to exist else there will be a break
                break;
            } else {
            	numberOfMembersExiting--; //exiting car queue will be decreased by 1
            	totalMembersInPark--; //total Member count will be decreased by 1
            }
            super.notifyViews();  //view gets updated

        }
        
        totalCars = getTotalRegularCars() + getTotalMembers() + getTotalReservations() + getTotalElectricals(); //total cars calculation
        super.notifyViews(); //view gets updated

        
    }
    
    /**
	 * This method simulates 'x' times
	 */
    
	public void steps(int x) {
		for(int i = 0; i < x; i++) {
			tick();
		}
	}

    /**
     * This method finds the first free location for a reservation car in the car park and returns it.
     * @return location
     */
    
    public Location getFirstFreeLocationForRes() {
    	for (int floor = 2; floor < getNumberOfFloors(); floor++) {
    		for (int row = 3; row <= 4 ; row++) {
    			for(int place = 0; place < getNumberOfPlaces(); place++) {
    				Location location = new Location(floor, row, place);
    					if(getCarAt(location) == null) {
    						return location;
    					}
    				}
    			}
    		}
    	
    	return null;
    }
    
    /**
     * This method finds the first free location for a Member car in the car park and returns it.
     * @return location
     */
    
    public Location getFirstFreeLocationForPass() {
    	for (int floor = 2; floor < getNumberOfFloors(); floor++) {
    		for (int row = 0; row <= 4; row++) {
    			for(int place = 0; place < getNumberOfPlaces(); place++) {
    				Location location = new Location(floor, row, place);
    					if(getCarAt(location) == null) {
    						return location;
    					}
    				}
    			}
    		}
    	
    	return null;
    }
    
    /**
     * This method finds the first free location for a Electrical car in the car park and returns it.
     * @return location
     */
    
    public Location getFirstFreeLocationForElec() {
    	for (int floor = 2; floor < getNumberOfFloors(); floor++) {
    		for (int row = 5; row <= 5 ; row++) {
    			for(int place = 0; place < getNumberOfPlaces(); place++) {
    				Location location = new Location(floor, row, place);
    					if(getCarAt(location) == null) {
    						return location;
    					}
    				}
    			}
    		}
    	
    	return null;
    }
    
    /**
     * This method finds the first free location for a Regular car in the car park and returns it.
     * @return location
     */
    
    public Location getFirstFreeLocationForRegular() {
    	for (int floor = 0; floor < 2; floor++) {
    		for (int row = 0; row < getNumberOfRows(); row++) {
    			for(int place = 0; place < getNumberOfPlaces(); place++) {
    				Location location = new Location(floor, row, place);
    					if(getCarAt(location) == null) {
    						return location;
    					}
    				}
    			}
    		}
    	
    	return null;
    }
    
    /**
     * Ticks for every car at the car park
     */
    
    public void tickCars() {
        for (int floor = 0; floor < getNumberOfFloors(); floor++) {
            for (int row = 0; row < getNumberOfRows(); row++) {
                for (int place = 0; place < getNumberOfPlaces(); place++) {
                    Location location = new Location(floor, row, place);
                    Car car = getCarAt(location);
                    if (car != null) {
                        car.tick();
                    }
                }
            }
        }
    }

    /**
     * @param location 
     * @return car 
     */
    
    public Car getCarAt(Location location) {
        if (!locationIsValid(location)) {
            return null;
        }
        return cars[location.getFloor()][location.getRow()][location.getPlace()];
    }

    /**
     * @param location
     * @param car
     * @return boolean 
     */
    
    public boolean setCarAt(Location location, Car car) {
        if (!locationIsValid(location)) {
            return false;
        }
        Car oldCar = getCarAt(location);
        if (oldCar == null) {
            cars[location.getFloor()][location.getRow()][location.getPlace()] = car;
            car.setLocation(location);
            return true;
        }
        return false;
    }
    
    /**
     * @param location 
     * @return boolean 
     */
    
    private boolean locationIsValid(Location location) {
        int floor = location.getFloor();
        int row = location.getRow();
        int place = location.getPlace();
        if (floor < 0 || floor >= numberOfFloors || row < 0 || row > numberOfRows || place < 0 || place > numberOfPlaces) {
            return false;
        }
        
        return true;
    }
    
    /**
     * @return car | null
     */
    
    public Car getFirstLeavingCar() {
        for (int floor = 0; floor < getNumberOfFloors(); floor++) {
            for (int row = 0; row < getNumberOfRows(); row++) {
                for (int place = 0; place < getNumberOfPlaces(); place++) {
                    Location location = new Location(floor, row, place);
                    Car car = getCarAt(location);
                    if (car != null && car.getMinutesLeft() <= 0) {
                        return car;
                    }
                }
            }
        }
        
        return null;
    }

    /**
     * @param location 
     * @return car | null 
     */
    
    public Car removeCarAt(Location location) {
        if (!locationIsValid(location)) {
            return null;
        }
        Car car = getCarAt(location);
        if (car == null) {
            return null;
        }
        cars[location.getFloor()][location.getRow()][location.getPlace()] = null;
        car.setLocation(null);
        return car;
    }
	
}