package me.project.model;

import java.util.LinkedList;
import java.util.Queue;

import me.project.abstracts.Car;

	/**
	 * Class for the queue's of cars
	 * @author Bryan Dijkhuizen, Thalisa Jagt
	 * @version 1.0
	 */

public class CarQueue {
    private Queue<Car> queue = new LinkedList<>();
    private boolean isOpen = true;

    
    /**
     * Ads a car to the queue and returns if the car has been added
     * @param car
     * @return boolean
     */
    
    public boolean addCar(Car car) {
        return queue.add(car);
    }

    /**
     * removes a car from the queue
     * @return car
     */
    
    public Car removeCar() {
        return queue.poll();
    }

    /**
     * returns carsInQueue 
     * @return cars queue in size
     */
    
    public int carsInQueue(){
    	return queue.size();
    }
    
    /**
     * @return isOpen
     */
    
    public boolean isOpen() {
    	return isOpen;
    }
    
    /**
     * sets isOpen
     * @param setIsOpen
     */
    
    public void setIsOpen(boolean isOpen) {
    	this.isOpen = isOpen;
    }
}