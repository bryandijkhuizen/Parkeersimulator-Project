package me.project.view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Stroke;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import me.project.abstracts.AbstractView;
import me.project.logic.CarParkingLogic;

/**
 * This class contains the lineChart
 * @author Bryan Dijkhuizen, Thalisa Jagt
 * @version 1.0
 */

@SuppressWarnings("serial")
public class lineChart extends AbstractView {
	
	private static final int width = 260;
    private static final int height = 520;
    
    private static final int borderSpace = 30;
    private static final int borderSpaceLeft = 50;
    
    private static final Color graphColor = Color.BLACK;
    private static final Stroke graphLine = new BasicStroke(3f);
    
	private static int MAX_VALUE = 1;
    private static int MIN_VALUE = 0;
    
    public static List<Integer> values = new ArrayList<Integer>();
    
    private int index = 0;
    
    private static final Color graphColor2 = Colors.DARK_RED;
    private static final Stroke graphLine2 = new BasicStroke(3f);
    
    private static int MAX_VALUE2 = 1;
    private static int MIN_VALUE2 = 0;
    
    public static List<Integer> regValues = new ArrayList<Integer>();
    
    private static final Color graphColor3 = Colors.DARK_YELLOW;
    private static final Stroke graphLine3 = new BasicStroke(3f);
    
    private static int MAX_VALUE3 = 1;
    private static int MIN_VALUE3 = 0;
    
    public static List<Integer> elecValues = new ArrayList<Integer>();
    
    private static final Color graphColor4 = Colors.MEMBER_BLUE;
    private static final Stroke graphLine4 = new BasicStroke(3f);
    
    private static int MAX_VALUE4 = 1;
    private static int MIN_VALUE4 = 0;
    
    public static List<Integer> memberValues = new ArrayList<Integer>();
    
    private static final Color graphColor5 = Colors.DARK_GREEN;
    private static final Stroke graphLine5 = new BasicStroke(3f);
    
    private static int MAX_VALUE5 = 1;
    private static int MIN_VALUE5 = 0;
    
    public static List<Integer> resValues = new ArrayList<Integer>();
  
    public lineChart(CarParkingLogic cpl) {
        super(cpl);
        
        values.add(cpl.getTotalCars());
        regValues.add(cpl.getTotalRegularCars());
        elecValues.add(cpl.getTotalElectricals());
        memberValues.add(cpl.getTotalMembers());
        resValues.add(cpl.getTotalReservations());
    }
    
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(width,height);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        CarParkingLogic cpl = (CarParkingLogic) super.model;
        index++;

        if (index % 15 == 0) {
        	values.add(cpl.getTotalCars());
	            if (values.size() > 500) {
	            	values.remove(0);
	            }  
        }
        
        if(index % 15 == 0) {
        	regValues.add(cpl.getTotalRegularCars());
        		if(regValues.size() > 500) {
        			regValues.remove(0);
        		}
        }
        
        if(index % 15 == 0) {
        	elecValues.add(cpl.getTotalElectricals());
        		if(elecValues.size() > 500) {
        			elecValues.remove(0);
        		}
        }
        
        if(index % 15 == 0) {
        	memberValues.add(cpl.getTotalMembers());
        		if(memberValues.size() > 500) {
        			memberValues.remove(0);
        		}
        }
        
        if(index % 15 == 0) {
        	resValues.add(cpl.getTotalReservations());
        		if(resValues.size() > 500) {
        			resValues.remove(0);
        		}
        }

        Graphics2D twoDimensionalGraphics = (Graphics2D) g;
        Graphics2D twoDimensionalGraphics2 = (Graphics2D) g;
        Graphics2D twoDimensionalGraphics3 = (Graphics2D) g;
        Graphics2D twoDimensionalGraphics4 = (Graphics2D) g;
        Graphics2D twoDimensionalGraphics5 = (Graphics2D) g;
 
        MAX_VALUE = java.lang.Math.max(Collections.max(values), MAX_VALUE);
        MIN_VALUE = java.lang.Math.max(Collections.min(values), MIN_VALUE);
        
        MAX_VALUE2 = java.lang.Math.max(Collections.max(regValues), MAX_VALUE2);
        MIN_VALUE2 = java.lang.Math.max(Collections.min(regValues), MIN_VALUE2);
        
        MAX_VALUE3 = java.lang.Math.max(Collections.max(elecValues), MAX_VALUE3);
        MIN_VALUE3 = java.lang.Math.max(Collections.min(elecValues), MIN_VALUE3);
        
        MAX_VALUE4 = java.lang.Math.max(Collections.max(memberValues), MAX_VALUE4);
        MIN_VALUE4 = java.lang.Math.max(Collections.min(memberValues), MIN_VALUE4);
        
        MAX_VALUE5 = java.lang.Math.max(Collections.max(resValues), MAX_VALUE5);
        MIN_VALUE5 = java.lang.Math.max(Collections.min(resValues), MIN_VALUE5);

        twoDimensionalGraphics.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		borderSpaceLeft,
        		borderSpace);
        twoDimensionalGraphics.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		getWidth() - borderSpace,
        		getHeight() - borderSpace);
        
        twoDimensionalGraphics2.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		borderSpaceLeft,
        		borderSpace);
        twoDimensionalGraphics2.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		getWidth() - borderSpace,
        		getHeight() - borderSpace);
        
        twoDimensionalGraphics3.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		borderSpaceLeft,
        		borderSpace);
        twoDimensionalGraphics3.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		getWidth() - borderSpace,
        		getHeight() - borderSpace);
        
        twoDimensionalGraphics4.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		borderSpaceLeft,
        		borderSpace);
        twoDimensionalGraphics4.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		getWidth() - borderSpace,
        		getHeight() - borderSpace);
        
        twoDimensionalGraphics5.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		borderSpaceLeft,
        		borderSpace);
        twoDimensionalGraphics5.drawLine(
        		borderSpaceLeft,
        		getHeight() - borderSpace,
        		getWidth() - borderSpace,
        		getHeight() - borderSpace);

        double xScale = ((double) getWidth() - 2 * borderSpace) / (values.size() - 1);
        double yScale = ((double) getHeight() - 2 * borderSpace) / (MAX_VALUE - MIN_VALUE);
       
        
        double xScale2 = ((double) getWidth() - 2 * borderSpace) / (regValues.size() - 1);
        double yScale2 = ((double) getHeight() - 2 * borderSpace) / (MAX_VALUE2 - MIN_VALUE2);
        
        double xScale3 = ((double) getWidth() - 2 * borderSpace) / (elecValues.size() - 1);
        double yScale3 = ((double) getHeight() - 2 * borderSpace) / (MAX_VALUE3 - MIN_VALUE3);
        
        double xScale4 = ((double) getWidth() - 2 * borderSpace) / (memberValues.size() - 1);
        double yScale4 = ((double) getHeight() - 2 * borderSpace) / (MAX_VALUE4 - MIN_VALUE4);
        
        double xScale5 = ((double) getWidth() - 2 * borderSpace) / (resValues.size() - 1);
        double yScale5 = ((double) getHeight() - 2 * borderSpace) / (MAX_VALUE5 - MIN_VALUE5);
        
	        List<Point> values2 = new ArrayList<Point>();
		        for (int i = 0; i < values.size(); i++) {
		            int x1 = (int) (i * xScale + borderSpaceLeft);
		            int y1 = (int) (((MAX_VALUE - values.get(i)) * yScale) + borderSpace);
	            
		            	values2.add(new Point(x1, y1));
	            
				            twoDimensionalGraphics.setColor(graphColor);
				            twoDimensionalGraphics.setStroke(graphLine);
				            	if (i > 0) {
					                int x0 = values2.get(i - 1).x;
					                int y0 = values2.get(i - 1).y;
					                	twoDimensionalGraphics.drawLine(x0, y0, x1, y1);
		            }
	        }
	        
	        List<Point> regValues2 = new ArrayList<Point>();
	        for (int i = 0; i < regValues.size(); i++) {
	            int x1 = (int) (i * xScale + borderSpaceLeft);
	            int y1 = (int) (((MAX_VALUE2 - regValues.get(i)) * yScale2) + borderSpace);
            
	            	regValues2.add(new Point(x1, y1));
            
			            twoDimensionalGraphics2.setColor(graphColor2);
			            twoDimensionalGraphics2.setStroke(graphLine2);
			            	if (i > 0) {
				                int x0 = regValues2.get(i - 1).x;
				                int y0 = regValues2.get(i - 1).y;
				                	twoDimensionalGraphics2.drawLine(x0, y0, x1, y1);
	            }
        }
	        
	        List<Point> elecValues2 = new ArrayList<Point>();
	        for (int i = 0; i < elecValues.size(); i++) {
	            int x1 = (int) (i * xScale + borderSpaceLeft);
	            int y1 = (int) (((MAX_VALUE3 - elecValues.get(i)) * yScale3) + borderSpace);
            
	            elecValues2.add(new Point(x1, y1));
            
			            twoDimensionalGraphics3.setColor(graphColor3);
			            twoDimensionalGraphics3.setStroke(graphLine3);
			            	if (i > 0) {
				                int x0 = elecValues2.get(i - 1).x;
				                int y0 = elecValues2.get(i - 1).y;
				                	twoDimensionalGraphics3.drawLine(x0, y0, x1, y1);
	            }
        }
	        
	        List<Point> memberValues2 = new ArrayList<Point>();
	        for (int i = 0; i < memberValues.size(); i++) {
	            int x1 = (int) (i * xScale + borderSpaceLeft);
	            int y1 = (int) (((MAX_VALUE4 - memberValues.get(i)) * yScale4) + borderSpace);
            
	            memberValues2.add(new Point(x1, y1));
            
			            twoDimensionalGraphics4.setColor(graphColor4);
			            twoDimensionalGraphics4.setStroke(graphLine4);
			            	if (i > 0) {
				                int x0 = memberValues2.get(i - 1).x;
				                int y0 = memberValues2.get(i - 1).y;
				                	twoDimensionalGraphics4.drawLine(x0, y0, x1, y1);
	            }
        }
	        
	        List<Point> resValues2 = new ArrayList<Point>();
	        for (int i = 0; i < resValues.size(); i++) {
	            int x1 = (int) (i * xScale + borderSpaceLeft);
	            int y1 = (int) (((MAX_VALUE5 - resValues.get(i)) * yScale5) + borderSpace);
            
	            resValues2.add(new Point(x1, y1));
            
			            twoDimensionalGraphics5.setColor(graphColor5);
			            twoDimensionalGraphics5.setStroke(graphLine5);
			            	if (i > 0) {
				                int x0 = resValues2.get(i - 1).x;
				                int y0 = resValues2.get(i - 1).y;
				                	twoDimensionalGraphics5.drawLine(x0, y0, x1, y1);
	            }
        }
        
        
        twoDimensionalGraphics.setColor(Color.BLACK);
        
        twoDimensionalGraphics.drawString(new Integer(MIN_VALUE).toString(), 10, 420);
        twoDimensionalGraphics.drawString(new Integer(MAX_VALUE).toString(), 10, 50);
        
    }  
}
