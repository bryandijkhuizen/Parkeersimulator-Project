package me.project.abstracts;

import javax.swing.JPanel;

	/**
	 * @author Bryan Dijkhuizen, Thalisa Jagt
	 * @version 1.0.0
	 */

@SuppressWarnings("serial")
public abstract class AbstractController extends JPanel {
	protected AbstractModel model;
	
	/**
	 * The constructor initializes the instance variable model with a model that applies to this controller.
	 * @param model 
	 */
	
	public AbstractController(AbstractModel model) {
		this.model = model;
	}
}